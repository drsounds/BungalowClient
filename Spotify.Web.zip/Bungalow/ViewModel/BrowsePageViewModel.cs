﻿using Bungalow.Spotify.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bungalow.ViewModel
{
    public class BrowsePageViewModel
    {
        public CategoryList Categories { get; set; }
    }
}
