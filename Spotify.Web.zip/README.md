# Bungalow
An open source desktop Spotify client in UWP

It will currently work through the Spotify Web API and will need the original client running in order to for the playback to work,
as it must utilize the playback API which act as a remote control.

# License
MIT
